
public interface Shapes 
{
	public abstract double getArea();
	public abstract double getDistance(Point2D a, Point2D b);
}
