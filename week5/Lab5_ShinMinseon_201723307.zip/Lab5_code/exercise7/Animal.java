// Fig..Lab5_U
// just show about polymorphism

public class Animal 
{

	void cry()
	{
		System.out.println("");
	}
	
}
