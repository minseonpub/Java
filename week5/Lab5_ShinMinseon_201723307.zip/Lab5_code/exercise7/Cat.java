//Fig..Lab5_U
public class Cat extends Animal
{
	void cry()
	{
		System.out.println("sound of dog: \"Miyaw Miyaw Miyaw\"");
	}
}
