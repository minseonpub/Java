//Fig..Lab5_U

public class Sheep extends Animal
{
	
	void cry()
	{
		System.out.println("sound of dog: \"Ba Ba Ba\"");
	}
}
