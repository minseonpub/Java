//Fig..Lab5_U
public class Dog extends Animal
{	
	void cry()
	{
		System.out.println("sound of dog: \"waw waw waw\"");
	}
}
