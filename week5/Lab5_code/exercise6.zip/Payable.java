// Fig. 10.11: Payable.java
// Payable interface declaration
public interface Payable 
{
	double getPaymentAmount();	// calculation payment; no implementation
}//end interface Payable
